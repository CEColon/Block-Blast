# Block-Blast
A Breakout clone created from scratch around 2018-2019
